//===============================================
// author : Cedric Caruzzo
// Github : https://github.com/CaruzzoC
// annee : 2020
//===============================================
//===================================================LINE CHART===========================================
new Chart(document.getElementById("line-chart-Direct"), {
  type: 'line',
  data: {
    labels: ["00:05","00:10","00:15","00:20","00:25","00:30"],
    datasets: [{ 
        data: [10,8,5,9,13,12],
        label: "Performance 1",
        borderColor: "#3e95cd",
      }
    ]
  },
  options: {
    title: {
      display: true,
      text: 'Direct Data'
    }
  }
});

new Chart(document.getElementById("line-chart-Comparaison"), {
  type: 'line',
  data: {
    labels: ["00:05","00:10","00:15","00:20","00:25","00:30"],
    datasets: [{ 
        data: [10,8,5,9,13,12],
        label: "Performance 1",
        borderColor: "#3e95cd",
        fill: false
      }, { 
        data: [15,12,13,14,7,10],
        label: "Performance 2",
        borderColor: "#8e5ea2",
        fill: false
      }
    ]
  },
  options: {
    title: {
      display: true,
      text: 'Comparaison de Performances'
    }
  }
});

//===========================================DOUGHNUT CHART==============================================

new Chart(document.getElementById("doughnut-chart1"), {
    type: 'doughnut',
    data: {
      labels: ["Performance 1","Performance 2"],
      datasets: [
        {
          label: "Distance Maximum",
          backgroundColor: ["#3e95cd", "#8e5ea2"],
          data: [13,15]
        }
      ]
    },
    options: {
      title: {
        display: true,
        text: 'Distance Maximum'
      }
    }
});

new Chart(document.getElementById("doughnut-chart2"), {
    type: 'doughnut',
    data: {
      labels: ["Performance 1","Performance 2"],
      datasets: [
        {
          label: "Distance Minimum",
          backgroundColor: ["#3e95cd", "#8e5ea2"],
          data: [5,7]
        }
      ]
    },
    options: {
      title: {
        display: true,
        text: 'Distance Minimum'
      }
    }
});

new Chart(document.getElementById("doughnut-chart3"), {
    type: 'doughnut',
    data: {
      labels: ["Performance 1","Performance 2"],
      datasets: [
        {
          label: "Vitesse Maximum",
          backgroundColor: ["#3e95cd", "#8e5ea2"],
          data: [9.36,10.8]
        }
      ]
    },
    options: {
      title: {
        display: true,
        text: 'Vitesse Maximum'
      }
    }
});

new Chart(document.getElementById("doughnut-chart4"), {
    type: 'doughnut',
    data: {
      labels: ["Performance 1","Performance 2"],
      datasets: [
        {
          label: "Vitesse Moyenne",
          backgroundColor: ["#3e95cd", "#8e5ea2"],
          data: [6.84,8.52]
        }
      ]
    },
    options: {
      title: {
        display: true,
        text: 'Vitesse Moyenne'
      }
    }
});



//===========================================DROPDOWN======================================================
var x = "Performance 1, Performance 2";

var options = x.split(",");

var select = document.getElementById('performanceChoice1');
for(var i=0; i<options.length; i++)
  select.options[i+1] = new Option(options[i], i);

var select = document.getElementById('performanceChoice2');
for(var i=0; i<options.length; i++)
  select.options[i+1] = new Option(options[i], i);

//==========================================GRAPH UPDATE==================================================

function updateConfigByMutating(chart) {
    chart.options.animation.duration = 0;
    chart.update();
}

function addData(chart, label, data) {
    chart.data.labels.push(label);
    chart.data.datasets.forEach((dataset) => {
        dataset.data.push(data);
    });
    updateConfigByMutating(chart);
}

function removeData(chart) {
    chart.data.labels.pop();
    chart.data.datasets.forEach((dataset) => {
        dataset.data.pop();
    });
    updateConfigByMutating(chart);
}