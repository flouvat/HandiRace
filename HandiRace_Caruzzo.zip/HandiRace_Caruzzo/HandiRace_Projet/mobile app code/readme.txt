Pour build l'app (Android ou iOS) à l'aide de Cordova, 
suivez les étapes indiquées dans le lien suivant:

https://cordova.apache.org/docs/en/latest/guide/cli/index.html#create-the-app